package com.tabachenko.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSiteApplication.class, args);
	}

}
